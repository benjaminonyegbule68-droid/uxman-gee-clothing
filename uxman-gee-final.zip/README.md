# Uxman Gee Clothing

Cloudflare Workers + D1 website for Uxman Gee Clothing.

## Setup
1. Create a Cloudflare D1 database named `uxman-gee-reviews`.
2. Put its ID in `wrangler.jsonc`.
3. Run `schema.sql` against the database.
4. Add Worker secrets:
   - `ADMIN_PASSWORD` — a strong admin password
   - `RESEND_API_KEY` — your Resend API key
5. Optional variables:
   - `ORDER_TO_EMAIL` — defaults to `benjaminonyegbule68@gmail.com`
   - `ORDER_FROM_EMAIL` — use a verified sending domain when ready
6. Connect the GitHub repository to Cloudflare Workers and deploy.

Do not commit API keys or passwords to GitHub.
