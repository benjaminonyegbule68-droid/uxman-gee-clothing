const json = (data, status = 200, extraHeaders = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=UTF-8", ...extraHeaders }
  });

const htmlEscape = (value = "") => String(value).replace(/[&<>\"']/g, c => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
}[c]));

const textEscape = (value = "") => htmlEscape(value).replace(/\r?\n/g, "<br>");

function randomId() {
  return crypto.randomUUID();
}

async function sign(value, secret) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  return [...new Uint8Array(signature)].map(b => b.toString(16).padStart(2, "0")).join("");
}

async function verifySession(request, env) {
  const cookie = request.headers.get("Cookie") || "";
  const match = cookie.match(/(?:^|;\s*)uxg_admin=([^;]+)/);
  if (!match || !env.ADMIN_PASSWORD) return false;
  const token = decodeURIComponent(match[1]);
  const [stamp, signature] = token.split(".");
  if (!stamp || !signature) return false;
  const age = Date.now() - Number(stamp);
  if (!Number.isFinite(age) || age < 0 || age > 8 * 60 * 60 * 1000) return false;
  const expected = await sign(stamp, env.ADMIN_PASSWORD);
  return expected === signature;
}

async function requireAdmin(request, env) {
  if (!(await verifySession(request, env))) {
    return json({ error: "Unauthorized." }, 401);
  }
  return null;
}

async function sendOrderEmail(env, order) {
  if (!env.RESEND_API_KEY) throw new Error("RESEND_API_KEY is not configured.");

  const from = env.ORDER_FROM_EMAIL || "Uxman Gee Website <onboarding@resend.dev>";
  const to = env.ORDER_TO_EMAIL || "benjaminonyegbule68@gmail.com";
  const subject = `New Uxman Gee Order — ${order.orderId}`;

  const html = `
    <div style="font-family:Arial,sans-serif;max-width:700px;margin:auto;color:#171717">
      <div style="background:#111;color:#fff;padding:24px">
        <h1 style="margin:0;color:#d4af37">UXMAN GEE CLOTHING</h1>
        <p style="margin:8px 0 0">New customer order</p>
      </div>
      <div style="padding:24px;background:#f7f5ef">
        <p><strong>Order ID:</strong> ${htmlEscape(order.orderId)}</p>
        <h2>Customer</h2>
        <p><strong>Name:</strong> ${htmlEscape(order.name)}<br>
        <strong>Phone:</strong> ${htmlEscape(order.phone)}</p>
        <h2>Order Details</h2>
        <p><strong>Clothing:</strong> ${htmlEscape(order.clothing)}<br>
        <strong>Delivery:</strong> ${htmlEscape(order.delivery)}<br>
        <strong>Address:</strong> ${htmlEscape(order.address || "Not provided")}</p>
        <h2>Custom Request</h2>
        <p style="background:#fff;padding:16px;border-radius:6px">${textEscape(order.description)}</p>
        <p><strong>Submitted:</strong> ${htmlEscape(order.createdAt)}</p>
      </div>
    </div>`;

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.RESEND_API_KEY}`
    },
    body: JSON.stringify({ from, to: [to], subject, html, reply_to: order.email || undefined })
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Email provider error: ${detail}`);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const method = request.method;

    if (url.pathname === "/api/health" && method === "GET") {
      return json({ ok: true, service: "Uxman Gee Clothing" });
    }

    if (url.pathname === "/api/orders" && method === "POST") {
      try {
        const body = await request.json();
        const name = String(body.name || "").trim();
        const phone = String(body.phone || "").trim();
        const email = String(body.email || "").trim();
        const clothing = String(body.clothing || "").trim();
        const delivery = String(body.delivery || "").trim();
        const address = String(body.address || "").trim();
        const description = String(body.description || "").trim();
        const honeypot = String(body.website || "").trim();

        if (honeypot) return json({ ok: true, message: "Order received." });
        if (!name || !phone || !clothing || !delivery || !description) {
          return json({ error: "Please complete all required order fields." }, 400);
        }
        if (name.length > 80 || phone.length > 30 || email.length > 120 || description.length > 2000 || address.length > 300) {
          return json({ error: "One or more fields are too long." }, 400);
        }
        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          return json({ error: "Please enter a valid email address." }, 400);
        }

        const orderId = `UXG-${new Date().toISOString().slice(0,10).replaceAll("-", "")}-${Math.floor(1000 + Math.random() * 9000)}`;
        const createdAt = new Date().toISOString();
        const order = { orderId, name, phone, email, clothing, delivery, address, description, createdAt };

        await sendOrderEmail(env, order);

        return json({ ok: true, orderId });
      } catch (error) {
        console.error(error);
        return json({ error: "We could not send the order right now. Please try again or contact us by WhatsApp." }, 502);
      }
    }

    if (url.pathname === "/api/reviews" && method === "GET") {
      const { results } = await env.DB.prepare(
        "SELECT id, name, text, created_at FROM reviews WHERE status = 'approved' ORDER BY created_at DESC LIMIT 50"
      ).all();
      return json(results);
    }

    if (url.pathname === "/api/reviews" && method === "POST") {
      try {
        const body = await request.json();
        const name = String(body.name || "").trim();
        const text = String(body.text || "").trim();
        if (!name || !text) return json({ error: "Name and review are required." }, 400);
        if (name.length > 50 || text.length > 500) return json({ error: "Please keep the name and review within the allowed length." }, 400);
        const id = randomId();
        await env.DB.prepare(
          "INSERT INTO reviews (id, name, text, status, created_at) VALUES (?, ?, ?, 'pending', ?)"
        ).bind(id, name, text, new Date().toISOString()).run();
        return json({ ok: true, message: "Review submitted for approval." }, 201);
      } catch (error) {
        console.error(error);
        return json({ error: "Could not submit the review." }, 500);
      }
    }

    if (url.pathname === "/api/admin/login" && method === "POST") {
      const body = await request.json().catch(() => ({}));
      if (!env.ADMIN_PASSWORD || String(body.password || "") !== env.ADMIN_PASSWORD) {
        return json({ error: "Invalid password." }, 401);
      }
      const stamp = String(Date.now());
      const signature = await sign(stamp, env.ADMIN_PASSWORD);
      return json({ ok: true }, 200, {
        "Set-Cookie": `uxg_admin=${encodeURIComponent(`${stamp}.${signature}`)}; Max-Age=28800; Path=/; HttpOnly; Secure; SameSite=Lax`
      });
    }

    if (url.pathname === "/api/admin/logout" && method === "POST") {
      return json({ ok: true }, 200, { "Set-Cookie": "uxg_admin=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Lax" });
    }

    if (url.pathname === "/api/admin/reviews" && method === "GET") {
      const denied = await requireAdmin(request, env);
      if (denied) return denied;
      const { results } = await env.DB.prepare(
        "SELECT id, name, text, status, created_at FROM reviews WHERE status = 'pending' ORDER BY created_at DESC"
      ).all();
      return json(results);
    }

    const reviewMatch = url.pathname.match(/^\/api\/admin\/reviews\/([^/]+)$/);
    if (reviewMatch && method === "POST") {
      const denied = await requireAdmin(request, env);
      if (denied) return denied;
      const id = reviewMatch[1];
      await env.DB.prepare("UPDATE reviews SET status = 'approved' WHERE id = ?").bind(id).run();
      return json({ ok: true });
    }

    if (reviewMatch && method === "DELETE") {
      const denied = await requireAdmin(request, env);
      if (denied) return denied;
      const id = reviewMatch[1];
      await env.DB.prepare("DELETE FROM reviews WHERE id = ?").bind(id).run();
      return json({ ok: true });
    }

    if (url.pathname === "/api/admin/status" && method === "GET") {
      return json({ authenticated: await verifySession(request, env) });
    }

    return env.ASSETS.fetch(request);
  }
};
